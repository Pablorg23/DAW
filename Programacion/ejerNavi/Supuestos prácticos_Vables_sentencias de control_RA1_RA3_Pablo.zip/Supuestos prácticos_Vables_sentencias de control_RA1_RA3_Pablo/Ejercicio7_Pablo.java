public class Ejercicio7_Pablo {

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        for (int i=7;i<=100;i+=7) {
            System.out.println(i);
        }
    }
}
