public class Ejercicio9_Pablo {

    public static void main(String[] args) {

        //a
        int q=0,p=1;
        //b
        float x=0.00f,y=1.11f,z=2.22f;
        //c
        char a,b,c;
        //d
        double raiz1=0.00,raiz2=1.11;
        //e
        long contador=0;
        //f
        short indicador=0;
        //g
        int indice=0;
        //h
        double precio=0.00,precioFinal=1.11;
        //i
        char car1='s',car2='n';
        //j
        byte valor=0;
        //k
        boolean primero=true,ultimo=false;
        //l
        String nombre ="Hola";
    }
}
