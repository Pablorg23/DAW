public class Ejercicio10_Pablo {

    public static void main(String[] args) {
        //a
        int edad;

        //b
        String codigoPostal;

        //c
        double altura;

        //d
        char genero;

        //e
        String nombre;

        //f
        int numeroDeHijos;

        //g
        double iva;

        //h
        int tallaCamisa;

        //i
        double peso;

        //j
        double precio;

        //k
        boolean alumnoRepetidor;

        //l
        String mensaje;

        //m
        char letra;

        //n
        boolean mayorEdad;

        //o
        int minutos;

        //p
        int dias;

        //q
        String matriculaCoche;

        //r
        int contador;

        //s
        boolean mayorDeEdad;

        //t
        String tallaCamiseta;
    }
}
