function mostrarTamañoBorde() {
    var tabla = document.getElementById("tabla1");
    var bordeActual = parseInt(tabla.border);
    alert("El tamaño actual del borde es: " + bordeActual);
 }